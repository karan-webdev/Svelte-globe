<script>
    let isMobileMenuOpen = false;
  </script>
  
  <nav class="navbar">
    <div class="logo">
      <a href="/">SanGoWay<br><span style='color: #21bf73; font-size: 2.42rem;'>Shipping</span></a>
    </div>
    
    <!-- Menu for large screens -->
    <div class="links desktop">
      <a href="#feature1">Home</a>
      <a href="#feature2">About Us</a>
      <a href="#about">Services</a>
      <a class="button" href="#about">Contact</a>
    </div>
  
    <!-- Hamburger menu for mobile -->
    <div class="mobile-menu-icon" on:click={() => isMobileMenuOpen = !isMobileMenuOpen}>
      <span></span>
      <span></span>
      <span></span>
    </div>
    
    <!-- Mobile menu -->
    {#if isMobileMenuOpen}
      <div class="links mobile">
        <a href="#feature1">Feature 1</a>
        <a href="#feature2">Feature 2</a>
        <a href="#about">About</a>
      </div>
    {/if}
  </nav>
  
  <style>
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      color: black;
      position: sticky;
      background-color: white;
      top: 0;
      z-index: 10;
      width: 100%;
      padding: 0;
      padding-block: 20px;
      height: 6rem;
    }
    
    .logo a {
      font-size: 2rem;
      font-weight: 600;
      color: #14161a;
      text-decoration: none;
    }

    .logo {
        margin-left: 10rem;
    }

  
    .links a {
      color: #14161a;
      text-decoration: none;
      margin: 0 1rem;
      font-weight: 600;
      font-size: 1.5rem;
      padding: 20px 30px;
    }

    .links a:nth-last-of-type(1) {
    margin-left: 1rem;
    margin-right: 10rem;
    }

    .button {
        background-color: #21bf73;
        color: white !important;
        padding: 20px 30px;
        border-radius: 8px;
    }

  
    .links a:hover {
      color: #22d3ee;
    }
  
    /* Desktop Menu */
    .desktop {
      display: flex;
    }
  
    /* Mobile Menu */
    .mobile {
      display: flex;
      flex-direction: column;
      position: absolute;
      top: 4rem;
      right: 1rem;
      background-color: #1e293b;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 1rem;
    }
  
    /* Hide mobile menu on default */
    .mobile a {
      margin: 0.5rem 0;
    }
  
    /* Mobile Hamburger Icon */
    .mobile-menu-icon {
      display: none;
      flex-direction: column;
      justify-content: space-between;
      width: 25px;
      height: 20px;
      cursor: pointer;
    }
  
    .mobile-menu-icon span {
      height: 4px;
      background-color: white;
      border-radius: 2px;
    }
  
    /* Responsive Design */
    @media (max-width: 768px) {
      .desktop {
        display: none;
      }
      
      .mobile-menu-icon {
        display: flex;
      }
    }
  </style>
  