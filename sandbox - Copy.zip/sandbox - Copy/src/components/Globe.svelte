<script>
    import world from "$data/world-110m.json";
    import * as topojson from "topojson-client";
    import { geoOrthographic, geoPath, geoInterpolate } from "d3-geo";
    import { scaleLinear } from "d3-scale";
    import { max } from "d3-array";
    import { select } from "d3-selection";
    import { spring } from "svelte/motion";
    import { onMount } from "svelte";
    import Glow from "./Glow.svelte";
    import data from "$data/data.json";
  
    let countries = topojson.feature(world, world.objects.countries).features;
    let borders = topojson.mesh(world, world.objects.countries, (a, b) => a !== b);
  
    let width = 400;
    $: height = width;
  
    // Add animation state
    let progress = 0;
    
    // Define coordinates for US and Georgia
    const US_COORDS = [-74.0060,  40.7128];
    const GEORGIA_COORDS = [43.3569, 42.3154];
  
    // Calculate optimal rotation angles for start and end points
    const startRotation = [-US_COORDS[0], -US_COORDS[1]];
    const endRotation = [-GEORGIA_COORDS[0], -GEORGIA_COORDS[1]];
  
    // Spring-based rotation state
    let xRotation = spring(startRotation[0], {
      stiffness: 0.08,
      damping: 0.4
    });
    
    let yRotation = spring(startRotation[1], {
      stiffness: 0.17,
      damping: 0.7
    });
  
    // Function to calculate progress and rotation based on scroll
    function updateFromScroll() {
      const scrollPercentage = (window.scrollY) / (document.documentElement.scrollHeight - window.innerHeight);
      progress = Math.min(Math.max(scrollPercentage, 0), 1);
  
      // Interpolate between start and end rotations
      $xRotation = startRotation[0] + (endRotation[0] - startRotation[0]) * progress;
      $yRotation = startRotation[1] + (endRotation[1] - startRotation[1]) * progress;
  
      // Add additional rotation to keep the path visible
      $xRotation += progress * 360; // Full rotation around the globe
    }
  
    // Listen to scroll events and update progress
    onMount(() => {
      window.addEventListener('scroll', updateFromScroll);
      return () => {
        window.removeEventListener('scroll', updateFromScroll);
      };
    });
  
    // Update projection and path on rotation change
    $: projection = geoOrthographic()
      .scale(width / 2)
      .rotate([$xRotation, $yRotation])
      .translate([width / 2, height / 2]);
  
    $: path = geoPath(projection);
  
    // Track projected endpoint coordinates
    $: startPoint = projection(US_COORDS);
    $: endPoint = projection(GEORGIA_COORDS);
  
    // Calculate plane position along the path
    $: {
      const interpolator = geoInterpolate(US_COORDS, GEORGIA_COORDS);
      const currentPoint = interpolator(progress);
      planePosition = projection(currentPoint);
      
      // Calculate angle for plane rotation
      if (planePosition && progress < 1) {
        const nextPoint = projection(interpolator(progress + 0.01));
        if (nextPoint) {
          const dx = nextPoint[0] - planePosition[0];
          const dy = nextPoint[1] - planePosition[1];
          planeRotation = (Math.atan2(dy, dx) * 180 / Math.PI) + 90;
        }
      }
    }
    let planePosition = null;
    let planeRotation = 0;
  
    function isPointVisible(coords) {
      const [x, y] = projection(coords);
      if (!x || !y) return false;
      
      const r = projection.rotate();
      const longitude = coords[0] * Math.PI / 180;
      const latitude = coords[1] * Math.PI / 180;
      const rotLong = -r[0] * Math.PI / 180;
      const rotLat = -r[1] * Math.PI / 180;
      
      const cosDistance = Math.sin(latitude) * Math.sin(rotLat) +
        Math.cos(latitude) * Math.cos(rotLat) * Math.cos(longitude - rotLong);
      
      return cosDistance >= 0;
    }
  
    // Calculate path segments
    $: {
      const interpolator = geoInterpolate(US_COORDS, GEORGIA_COORDS);
      const numPoints = 100;
      const allPoints = Array.from({ length: numPoints }, (_, i) => {
        const point = interpolator(i / (numPoints - 1));
        return {
          coords: point,
          projected: projection(point)
        };
      });
  
      let currentSegment = [];
      let segments = [];
      
      allPoints.forEach(({coords, projected}) => {
        if (projected && isPointVisible(coords)) {
          currentSegment.push(projected);
        } else if (currentSegment.length > 0) {
          segments.push([...currentSegment]);
          currentSegment = [];
        }
      });
      
      if (currentSegment.length > 0) {
        segments.push(currentSegment);
      }
  
      pathSegments = segments;
    }
  
    let pathSegments = [];
  
    // Set up color scale for countries
    countries.forEach(country => {
      const metadata = data?.find(d => d.id === country.id);
      if (metadata) {
        country.population = metadata.population;
        country.country = metadata.country;
      }
    });
  
    const colorScale = scaleLinear()
      .domain([0, max(data, d => d.population)])
      .range(["#26362e", "#21bf73"]);
  
    let globe;
  
      // Calculate light position based on rotation
      $: lightAngle = {
      x: -$xRotation * (Math.PI / 180),
      y: -$yRotation * (Math.PI / 180)
    };
  
    // Calculate light vector components for shading
    $: lightVector = {
      x: Math.cos(lightAngle.y) * Math.sin(lightAngle.x),
      y: -Math.sin(lightAngle.y),
      z: Math.cos(lightAngle.y) * Math.cos(lightAngle.x)
    };
  </script>
  

  
  <div class='chart-container' bind:clientWidth={width}>
    <svg {width} {height} bind:this={globe}>
      <Glow />
  
      <defs>
        <!-- Ambient light gradient -->
        <radialGradient id="globeGradient" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#ffffff" stop-opacity="0.3" />
          <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
        </radialGradient>
  
        <!-- Dynamic light gradient -->
        <radialGradient 
          id="sphericalGradient" 
          cx={50 + lightVector.x * 50 + "%"} 
          cy={50 + lightVector.y * 50 + "%"}
        >
          <stop offset="0%" stop-color="#ffffff" stop-opacity="0.4" />
          <stop offset="50%" stop-color="#ffffff" stop-opacity="0.1" />
          <stop offset="100%" stop-color="#000000" stop-opacity="0.4" />
        </radialGradient>
  
        <!-- Shadow filter -->
        <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="4" />
          <feOffset dx="4" dy="4" result="offsetblur" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.3" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
  
        <!-- Glow remains the same as before -->
        
      </defs>
  
      <circle 
        r={width / 2} 
        cx={width / 2} 
        cy={height / 2} 
        fill="#63666A"
        filter="url(#glow)" 
      />
  
      <!-- Base globe sphere with shadow -->
      <circle 
        r={width / 2} 
        cx={width / 2} 
        cy={height / 2} 
        fill="#63666A"
        filter="url(#glow)"
      />
  
       <!-- Lighting layer -->
       <circle 
       r={width / 2} 
       cx={width / 2} 
       cy={height / 2} 
       fill="url(#sphericalGradient)"
       opacity="1"
     />
  
      <!-- Countries with adjusted coloring for depth -->
      {#each countries as country}
        <path 
          d={path(country)} 
          fill={colorScale(country.population || 0)}
          stroke="none"
          style="mix-blend-mode: hard-light"
        />
      {/each}
  
      <!-- Ambient light overlay -->
      <circle 
        r={width / 2} 
        cx={width / 2} 
        cy={height / 2} 
        fill="url(#globeGradient)"
        style="mix-blend-mode: soft-light"
      />
  
       <!-- Borders with adjusted opacity -->
       <path 
       d={path(borders)} 
       fill="none" 
       stroke="none" 
       stroke-opacity="0.3"
     />
  
      <!-- Flight path segments with glow -->
      {#each pathSegments as segment}
        <path
          d={`M ${segment.map(p => p.join(',')).join(' L ')}`}
          fill="none"
          stroke="#ffffff"
          stroke-width="2"
          stroke-dasharray="4,4"
          opacity="0.6"
          filter="url(#glow)"
        />
      {/each}
  
  
    
  
      <path d={path(borders)} fill="none" stroke="none" />
  
  
       <!-- Point markers with glow -->
       {#if startPoint && isPointVisible(US_COORDS)}
       <g transform={`translate(${startPoint})`}>
         <circle r="4" fill="#fec201" filter="url(#glow)" />
         <circle r="2" fill="#FFFFFF" />
       </g>
     {/if}
  
     
  
      {#if endPoint && isPointVisible(GEORGIA_COORDS)}
      <g transform={`translate(${endPoint})`}>
        <circle r="4" fill="#fec201" filter="url(#glow)" />
        <circle r="2" fill="#FFFFFF" />
      </g>
    {/if}
  
       <!-- Animated plane with shadow -->
       {#if planePosition && 
        isPointVisible(projection.invert(planePosition)) && 
        (isPointVisible(US_COORDS) || isPointVisible(GEORGIA_COORDS) || pathSegments.length > 0)}
      <g transform={`translate(${planePosition}) rotate(${planeRotation}) scale(0.07) translate(-256, -256)`}>
        <path 
          d="M511.06,286.261c-0.387-10.849-7.42-20.615-18.226-25.356l-193.947-74.094 C298.658,78.15,285.367,3.228,256.001,3.228c-29.366,0-42.657,74.922-42.885,183.583L19.167,260.904 C8.345,265.646,1.33,275.412,0.941,286.261L0.008,311.97c-0.142,3.886,1.657,7.623,4.917,10.188 c3.261,2.564,7.597,3.684,11.845,3.049c0,0,151.678-22.359,198.037-29.559c1.85,82.016,4.019,127.626,4.019,127.626l-51.312,24.166 c-6.046,2.38-10.012,8.206-10.012,14.701v9.465c0,4.346,1.781,8.505,4.954,11.493c3.155,2.987,7.403,4.539,11.74,4.292l64.83-3.667 c2.08,14.436,8.884,25.048,16.975,25.048c8.091,0,14.877-10.612,16.975-25.048l64.832,3.667c4.336,0.246,8.584-1.305,11.738-4.292 c3.174-2.988,4.954-7.148,4.954-11.493v-9.465c0-6.495-3.966-12.321-10.012-14.701l-51.329-24.166c0,0,2.186-45.61,4.037-127.626 c46.358,7.2,198.036,29.559,198.036,29.559c4.248,0.635,8.602-0.485,11.845-3.049c3.261-2.565,5.041-6.302,4.918-10.188 L511.06,286.261z"
          fill="#ffffff"
          stroke="black"
          stroke-width="10"
          filter="url(#shadow)"
        />
      </g>
      {/if}
    </svg>
  </div>
  
  <style>
    .chart-container {
      max-width: 468px;
      margin: auto;
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 500px;
    }
  
    /* :global(body) {
      background-color: rgb(21, 21, 21)  } */
  
    svg {
      overflow: visible;
    }
  </style>