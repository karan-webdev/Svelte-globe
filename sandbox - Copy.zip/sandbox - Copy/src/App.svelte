<script>
  import Navbar from './components/Navbar.svelte';
  import Globe from './components/Globe.svelte'; // Import the Globe component
</script>


<Globe />



<div class='content' style='height: 500vh !important;'>
  
</div>



<style>
  /* Flexbox container to hold both elements */
  .content {
    display: flex;
    align-items: center; /* Vertically center the items */
    justify-content: flex-start; /* Align items to the start horizontally */
    height: 100vh;
  }

  /* Styling for the h1, relative by default */
  h1 {
    position: relative;
    left: 25%;
    transform: translate(-50%, -50%);
  }

  h1 .para {
    padding-top: 2rem;
    line-height: 2rem;
    font-size: 1.5rem;
    font-weight: 600;
  }

  h1 .para

 
 
</style>
